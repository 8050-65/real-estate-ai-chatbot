--
-- PostgreSQL database dump
--

\restrict bgWFrpL2nYrZ5t63tOHb3NNmJVceluAEZeoKILhmAXEIVSTARg80sztKgrU1YH2

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: rootuser
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO rootuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_query_logs; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.ai_query_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    query_text text NOT NULL,
    interpreted_query text,
    result_type character varying(50),
    result_summary text,
    execution_ms integer,
    was_successful boolean DEFAULT true NOT NULL,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_query_logs OWNER TO rootuser;

--
-- Name: analytics_summary; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.analytics_summary (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    summary_date date NOT NULL,
    total_messages integer DEFAULT 0,
    total_sessions integer DEFAULT 0,
    total_visits_scheduled integer DEFAULT 0,
    total_visits_completed integer DEFAULT 0,
    average_response_time_ms integer DEFAULT 0,
    total_tokens_used integer DEFAULT 0,
    failed_queries integer DEFAULT 0,
    success_rate double precision DEFAULT 0.0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cache_invalidated_at timestamp with time zone
);


ALTER TABLE public.analytics_summary OWNER TO rootuser;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_code character varying(50) NOT NULL,
    user_id uuid,
    request_id character varying(36),
    action character varying(100) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(255),
    changes jsonb DEFAULT '{}'::jsonb,
    prompt_input character varying(2000),
    ai_response_summary character varying(500),
    ai_provider character varying(50),
    confidence numeric(3,2),
    ip_address character varying(50),
    user_agent character varying(500),
    execution_ms integer,
    error_code character varying(50),
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO rootuser;

--
-- Name: bot_configs; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.bot_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    persona_name character varying(100) DEFAULT 'Aria'::character varying NOT NULL,
    greeting_message text NOT NULL,
    tone character varying(20) DEFAULT 'friendly'::character varying NOT NULL,
    active_hours_start time without time zone DEFAULT '09:00:00'::time without time zone NOT NULL,
    active_hours_end time without time zone DEFAULT '21:00:00'::time without time zone NOT NULL,
    after_hours_message text NOT NULL,
    language character varying(10) DEFAULT 'en'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_tone CHECK (((tone)::text = ANY ((ARRAY['formal'::character varying, 'friendly'::character varying])::text[])))
);


ALTER TABLE public.bot_configs OWNER TO rootuser;

--
-- Name: conversation_logs; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.conversation_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    session_id uuid,
    whatsapp_number character varying(20) NOT NULL,
    leadrat_lead_id character varying(100),
    message text NOT NULL,
    role character varying(10) NOT NULL,
    intent character varying(100),
    confidence numeric(4,3),
    media_shared jsonb DEFAULT '[]'::jsonb,
    processing_ms integer,
    llm_provider character varying(20),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sync_status character varying(50) DEFAULT 'pending'::character varying,
    sync_error text,
    source_updated_at timestamp with time zone,
    record_checksum character varying(64),
    CONSTRAINT check_role CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'bot'::character varying, 'rm'::character varying])::text[])))
);


ALTER TABLE public.conversation_logs OWNER TO rootuser;

--
-- Name: conversation_memory; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.conversation_memory (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id uuid NOT NULL,
    tenant_code character varying(50) NOT NULL,
    recent_messages jsonb DEFAULT '[]'::jsonb NOT NULL,
    summarized_context text,
    compressed_context jsonb DEFAULT '{}'::jsonb,
    last_intent character varying(100),
    last_filters jsonb DEFAULT '{}'::jsonb,
    last_entity_extraction jsonb DEFAULT '{}'::jsonb,
    active_until timestamp with time zone,
    expires_at timestamp with time zone DEFAULT (now() + '24:00:00'::interval) NOT NULL,
    archived_at timestamp with time zone,
    archival_reason character varying(100),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.conversation_memory OWNER TO rootuser;

--
-- Name: data_sync_logs; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.data_sync_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    sync_type character varying(50) NOT NULL,
    source character varying(100) DEFAULT 'leadrat_api'::character varying NOT NULL,
    target character varying(100) DEFAULT 'chatbot_crm'::character varying NOT NULL,
    entity_type character varying(100) NOT NULL,
    tenant_code character varying(50) NOT NULL,
    records_synced integer DEFAULT 0,
    records_created integer DEFAULT 0,
    records_updated integer DEFAULT 0,
    records_deleted integer DEFAULT 0,
    records_failed integer DEFAULT 0,
    records_skipped integer DEFAULT 0,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    duration_ms integer,
    status character varying(50) NOT NULL,
    error_message text,
    error_count integer DEFAULT 0,
    sync_version integer DEFAULT 1,
    idempotency_key character varying(255),
    conflict_resolution_policy character varying(50),
    conflicts_detected integer DEFAULT 0,
    conflicts_resolved integer DEFAULT 0,
    initiated_by character varying(100),
    initiated_by_user_id uuid,
    webhook_id character varying(255),
    avg_processing_time_ms integer,
    throughput_records_per_second numeric(10,2),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.data_sync_logs OWNER TO rootuser;

--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO rootuser;

--
-- Name: saved_reports; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.saved_reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    query_text text NOT NULL,
    chart_type character varying(50) DEFAULT 'table'::character varying NOT NULL,
    filters jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    schedule character varying(20) DEFAULT 'none'::character varying NOT NULL,
    schedule_recipients jsonb DEFAULT '[]'::jsonb NOT NULL,
    last_run_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_chart_type CHECK (((chart_type)::text = ANY ((ARRAY['table'::character varying, 'bar'::character varying, 'line'::character varying, 'pie'::character varying, 'funnel'::character varying, 'kpi'::character varying])::text[]))),
    CONSTRAINT check_schedule CHECK (((schedule)::text = ANY ((ARRAY['none'::character varying, 'daily'::character varying, 'weekly'::character varying, 'monthly'::character varying])::text[])))
);


ALTER TABLE public.saved_reports OWNER TO rootuser;

--
-- Name: site_visits; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.site_visits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    leadrat_lead_id character varying(100) NOT NULL,
    leadrat_project_id character varying(100),
    leadrat_visit_id character varying(100),
    customer_name character varying(200) NOT NULL,
    whatsapp_number character varying(20) NOT NULL,
    rm_id uuid,
    scheduled_at timestamp with time zone NOT NULL,
    duration_minutes integer DEFAULT 60 NOT NULL,
    visitor_count integer DEFAULT 1 NOT NULL,
    status character varying(20) DEFAULT 'scheduled'::character varying NOT NULL,
    notes text,
    google_maps_link text,
    reminder_24h_sent boolean DEFAULT false NOT NULL,
    reminder_2h_sent boolean DEFAULT false NOT NULL,
    leadrat_synced boolean DEFAULT false NOT NULL,
    leadrat_sync_error text,
    cancelled_reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sync_status character varying(50) DEFAULT 'pending'::character varying,
    sync_error text,
    last_synced_at timestamp with time zone,
    source_updated_at timestamp with time zone,
    record_checksum character varying(64),
    idempotency_key character varying(255),
    leadrat_status_synced boolean NOT NULL,
    leadrat_sync_at timestamp(6) without time zone,
    reminder24h_sent boolean NOT NULL,
    reminder2h_sent boolean NOT NULL,
    CONSTRAINT check_status CHECK (((status)::text = ANY ((ARRAY['scheduled'::character varying, 'confirmed'::character varying, 'completed'::character varying, 'cancelled'::character varying, 'no_show'::character varying])::text[]))),
    CONSTRAINT check_visitor_count CHECK ((visitor_count > 0))
);


ALTER TABLE public.site_visits OWNER TO rootuser;

--
-- Name: tenant_configs; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.tenant_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_code character varying(50) NOT NULL,
    leadrat_code character varying(50) NOT NULL,
    leadrat_api_key character varying(500) NOT NULL,
    leadrat_secret_key character varying(500) NOT NULL,
    leadrat_auth_url character varying(500) NOT NULL,
    leadrat_base_url character varying(500) NOT NULL,
    last_lead_sync timestamp with time zone,
    last_property_sync timestamp with time zone,
    last_project_sync timestamp with time zone,
    sync_enabled boolean DEFAULT true NOT NULL,
    sync_frequency_minutes integer DEFAULT 60 NOT NULL,
    webhook_enabled boolean DEFAULT false NOT NULL,
    webhook_secret character varying(500),
    webhook_url character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_sync_frequency CHECK ((sync_frequency_minutes >= 5))
);


ALTER TABLE public.tenant_configs OWNER TO rootuser;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(100) NOT NULL,
    plan character varying(50) DEFAULT 'starter'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tenants OWNER TO rootuser;

--
-- Name: users; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    full_name character varying(200) NOT NULL,
    role character varying(50) NOT NULL,
    whatsapp_number character varying(20),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    assigned_leads_count integer DEFAULT 0,
    CONSTRAINT check_role CHECK (((role)::text = ANY ((ARRAY['ADMIN'::character varying, 'SALES_MANAGER'::character varying, 'RM'::character varying, 'MARKETING'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO rootuser;

--
-- Name: whatsapp_sessions; Type: TABLE; Schema: public; Owner: rootuser
--

CREATE TABLE public.whatsapp_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    whatsapp_number character varying(20) NOT NULL,
    leadrat_lead_id character varying(100),
    session_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    visit_booking_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    current_intent character varying(100),
    message_count integer DEFAULT 0 NOT NULL,
    last_active timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sync_status character varying(50) DEFAULT 'pending'::character varying,
    sync_error text,
    last_synced_at timestamp with time zone,
    source_updated_at timestamp with time zone,
    record_checksum character varying(64),
    idempotency_key character varying(255)
);


ALTER TABLE public.whatsapp_sessions OWNER TO rootuser;

--
-- Data for Name: ai_query_logs; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.ai_query_logs (id, tenant_id, user_id, query_text, interpreted_query, result_type, result_summary, execution_ms, was_successful, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: analytics_summary; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.analytics_summary (id, tenant_id, summary_date, total_messages, total_sessions, total_visits_scheduled, total_visits_completed, average_response_time_ms, total_tokens_used, failed_queries, success_rate, created_at, updated_at, cache_invalidated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.audit_logs (id, tenant_code, user_id, request_id, action, entity_type, entity_id, changes, prompt_input, ai_response_summary, ai_provider, confidence, ip_address, user_agent, execution_ms, error_code, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: bot_configs; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.bot_configs (id, tenant_id, persona_name, greeting_message, tone, active_hours_start, active_hours_end, after_hours_message, language, is_active, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000020	00000000-0000-0000-0000-000000000001	Aria	Hi! I am Aria your real estate assistant. How can I help you today?	friendly	09:00:00	21:00:00	Thanks for reaching out! Our team will respond 9AM-9PM.	en	t	2026-04-28 17:07:51.530476+00	2026-04-28 17:07:51.530476+00
\.


--
-- Data for Name: conversation_logs; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.conversation_logs (id, tenant_id, session_id, whatsapp_number, leadrat_lead_id, message, role, intent, confidence, media_shared, processing_ms, llm_provider, created_at, updated_at, sync_status, sync_error, source_updated_at, record_checksum) FROM stdin;
\.


--
-- Data for Name: conversation_memory; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.conversation_memory (id, session_id, tenant_code, recent_messages, summarized_context, compressed_context, last_intent, last_filters, last_entity_extraction, active_until, expires_at, archived_at, archival_reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: data_sync_logs; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.data_sync_logs (id, sync_type, source, target, entity_type, tenant_code, records_synced, records_created, records_updated, records_deleted, records_failed, records_skipped, started_at, completed_at, duration_ms, status, error_message, error_count, sync_version, idempotency_key, conflict_resolution_policy, conflicts_detected, conflicts_resolved, initiated_by, initiated_by_user_id, webhook_id, avg_processing_time_ms, throughput_records_per_second, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	create core tables	SQL	V1__create_core_tables.sql	1125435029	rootuser	2026-04-28 17:07:51.144017	83	t
2	2	create conversation tables	SQL	V2__create_conversation_tables.sql	8332292	rootuser	2026-04-28 17:07:51.296713	88	t
3	3	create visit tables	SQL	V3__create_visit_tables.sql	-1916810683	rootuser	2026-04-28 17:07:51.404105	34	t
4	4	create analytics tables	SQL	V4__create_analytics_tables.sql	857462211	rootuser	2026-04-28 17:07:51.449727	58	t
5	5	seed default data	SQL	V5__seed_default_data.sql	-1177000426	rootuser	2026-04-28 17:07:51.523128	11	t
6	6	add tenant configs	SQL	V6__add_tenant_configs.sql	704313063	rootuser	2026-04-28 17:07:51.545768	28	t
7	7	add conversation memory	SQL	V7__add_conversation_memory.sql	1954972106	rootuser	2026-04-28 17:07:51.581999	30	t
8	8	add audit logs	SQL	V8__add_audit_logs.sql	1626123654	rootuser	2026-04-28 17:07:51.623237	30	t
9	9	add sync metadata columns	SQL	V9__add_sync_metadata_columns.sql	387831839	rootuser	2026-04-28 17:07:51.661745	48	t
10	10	add enhanced sync logs	SQL	V10__add_enhanced_sync_logs.sql	397442460	rootuser	2026-04-28 17:07:51.729467	84	t
\.


--
-- Data for Name: saved_reports; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.saved_reports (id, tenant_id, user_id, name, query_text, chart_type, filters, is_pinned, schedule, schedule_recipients, last_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: site_visits; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.site_visits (id, tenant_id, leadrat_lead_id, leadrat_project_id, leadrat_visit_id, customer_name, whatsapp_number, rm_id, scheduled_at, duration_minutes, visitor_count, status, notes, google_maps_link, reminder_24h_sent, reminder_2h_sent, leadrat_synced, leadrat_sync_error, cancelled_reason, created_at, updated_at, sync_status, sync_error, last_synced_at, source_updated_at, record_checksum, idempotency_key, leadrat_status_synced, leadrat_sync_at, reminder24h_sent, reminder2h_sent) FROM stdin;
\.


--
-- Data for Name: tenant_configs; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.tenant_configs (id, tenant_code, leadrat_code, leadrat_api_key, leadrat_secret_key, leadrat_auth_url, leadrat_base_url, last_lead_sync, last_property_sync, last_project_sync, sync_enabled, sync_frequency_minutes, webhook_enabled, webhook_secret, webhook_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.tenants (id, name, slug, plan, is_active, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	CRM Chatbot	black	enterprise	t	2026-04-28 17:07:51.530476+00	2026-04-28 17:07:51.530476+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.users (id, tenant_id, email, password_hash, full_name, role, whatsapp_number, is_active, created_at, updated_at, assigned_leads_count) FROM stdin;
00000000-0000-0000-0000-000000000010	00000000-0000-0000-0000-000000000001	admin@crm-cbt.com	$2b$10$FNi4SUkVr.SGdt8rRFHqAuMKXHRMoxZtIYZaUUdTmKuF4vKAq5fry	System Admin	ADMIN	\N	t	2026-04-28 17:07:51.530476+00	2026-04-28 17:07:51.530476+00	0
00000000-0000-0000-0000-000000000011	00000000-0000-0000-0000-000000000001	sales@crm-cbt.com	$2b$10$FNi4SUkVr.SGdt8rRFHqAuMKXHRMoxZtIYZaUUdTmKuF4vKAq5fry	John Sales	SALES_MANAGER	+919876543210	t	2026-04-28 17:07:51.530476+00	2026-04-28 17:07:51.530476+00	0
00000000-0000-0000-0000-000000000012	00000000-0000-0000-0000-000000000001	rm@crm-cbt.com	$2b$10$FNi4SUkVr.SGdt8rRFHqAuMKXHRMoxZtIYZaUUdTmKuF4vKAq5fry	Jane RM	RM	+919876543211	t	2026-04-28 17:07:51.530476+00	2026-04-28 17:07:51.530476+00	0
\.


--
-- Data for Name: whatsapp_sessions; Type: TABLE DATA; Schema: public; Owner: rootuser
--

COPY public.whatsapp_sessions (id, tenant_id, whatsapp_number, leadrat_lead_id, session_data, visit_booking_state, current_intent, message_count, last_active, created_at, updated_at, sync_status, sync_error, last_synced_at, source_updated_at, record_checksum, idempotency_key) FROM stdin;
\.


--
-- Name: ai_query_logs ai_query_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_pkey PRIMARY KEY (id);


--
-- Name: analytics_summary analytics_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.analytics_summary
    ADD CONSTRAINT analytics_summary_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bot_configs bot_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.bot_configs
    ADD CONSTRAINT bot_configs_pkey PRIMARY KEY (id);


--
-- Name: conversation_logs conversation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.conversation_logs
    ADD CONSTRAINT conversation_logs_pkey PRIMARY KEY (id);


--
-- Name: conversation_memory conversation_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.conversation_memory
    ADD CONSTRAINT conversation_memory_pkey PRIMARY KEY (id);


--
-- Name: data_sync_logs data_sync_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.data_sync_logs
    ADD CONSTRAINT data_sync_logs_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: saved_reports saved_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.saved_reports
    ADD CONSTRAINT saved_reports_pkey PRIMARY KEY (id);


--
-- Name: site_visits site_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.site_visits
    ADD CONSTRAINT site_visits_pkey PRIMARY KEY (id);


--
-- Name: tenant_configs tenant_configs_leadrat_code_key; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.tenant_configs
    ADD CONSTRAINT tenant_configs_leadrat_code_key UNIQUE (leadrat_code);


--
-- Name: tenant_configs tenant_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.tenant_configs
    ADD CONSTRAINT tenant_configs_pkey PRIMARY KEY (id);


--
-- Name: tenant_configs tenant_configs_tenant_code_key; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.tenant_configs
    ADD CONSTRAINT tenant_configs_tenant_code_key UNIQUE (tenant_code);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: users ukdms6tsnbugy9927cn4kwci01a; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT ukdms6tsnbugy9927cn4kwci01a UNIQUE (email, tenant_id);


--
-- Name: bot_configs unique_tenant_bot; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.bot_configs
    ADD CONSTRAINT unique_tenant_bot UNIQUE (tenant_id);


--
-- Name: analytics_summary unique_tenant_date; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.analytics_summary
    ADD CONSTRAINT unique_tenant_date UNIQUE (tenant_id, summary_date);


--
-- Name: tenant_configs unique_tenant_leadrat; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.tenant_configs
    ADD CONSTRAINT unique_tenant_leadrat UNIQUE (tenant_code, leadrat_code);


--
-- Name: saved_reports unique_tenant_report; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.saved_reports
    ADD CONSTRAINT unique_tenant_report UNIQUE (tenant_id, name);


--
-- Name: whatsapp_sessions unique_tenant_whatsapp; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.whatsapp_sessions
    ADD CONSTRAINT unique_tenant_whatsapp UNIQUE (tenant_id, whatsapp_number);


--
-- Name: users users_email_tenant_id_key; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_tenant_id_key UNIQUE (email, tenant_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: whatsapp_sessions whatsapp_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.whatsapp_sessions
    ADD CONSTRAINT whatsapp_sessions_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_activity_leadrat_lead; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_activity_leadrat_lead ON public.site_visits USING btree (leadrat_lead_id);


--
-- Name: idx_activity_leadrat_project; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_activity_leadrat_project ON public.site_visits USING btree (leadrat_project_id);


--
-- Name: idx_activity_scheduled; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_activity_scheduled ON public.site_visits USING btree (scheduled_at);


--
-- Name: idx_activity_status; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_activity_status ON public.site_visits USING btree (status);


--
-- Name: idx_activity_tenant; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_activity_tenant ON public.site_visits USING btree (tenant_id);


--
-- Name: idx_ai_query_logs_created_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_ai_query_logs_created_at ON public.ai_query_logs USING btree (created_at);


--
-- Name: idx_ai_query_logs_success; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_ai_query_logs_success ON public.ai_query_logs USING btree (was_successful);


--
-- Name: idx_ai_query_logs_tenant_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_ai_query_logs_tenant_id ON public.ai_query_logs USING btree (tenant_id);


--
-- Name: idx_ai_query_logs_user_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_ai_query_logs_user_id ON public.ai_query_logs USING btree (user_id);


--
-- Name: idx_analytics_summary_date; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_analytics_summary_date ON public.analytics_summary USING btree (summary_date);


--
-- Name: idx_analytics_summary_tenant_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_analytics_summary_tenant_id ON public.analytics_summary USING btree (tenant_id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_entity; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_audit_logs_entity ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: idx_audit_logs_request_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_audit_logs_request_id ON public.audit_logs USING btree (request_id);


--
-- Name: idx_audit_logs_tenant; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_audit_logs_tenant ON public.audit_logs USING btree (tenant_code);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_bot_configs_tenant_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_bot_configs_tenant_id ON public.bot_configs USING btree (tenant_id);


--
-- Name: idx_conversation_logs_created_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_logs_created_at ON public.conversation_logs USING btree (created_at);


--
-- Name: idx_conversation_logs_intent; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_logs_intent ON public.conversation_logs USING btree (intent);


--
-- Name: idx_conversation_logs_leadrat_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_logs_leadrat_id ON public.conversation_logs USING btree (leadrat_lead_id);


--
-- Name: idx_conversation_logs_session_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_logs_session_id ON public.conversation_logs USING btree (session_id);


--
-- Name: idx_conversation_logs_source_updated; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_logs_source_updated ON public.conversation_logs USING btree (source_updated_at DESC);


--
-- Name: idx_conversation_logs_sync_status; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_logs_sync_status ON public.conversation_logs USING btree (sync_status);


--
-- Name: idx_conversation_logs_tenant_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_logs_tenant_id ON public.conversation_logs USING btree (tenant_id);


--
-- Name: idx_conversation_memory_active_until; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_memory_active_until ON public.conversation_memory USING btree (active_until);


--
-- Name: idx_conversation_memory_archived_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_memory_archived_at ON public.conversation_memory USING btree (archived_at);


--
-- Name: idx_conversation_memory_expires_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_memory_expires_at ON public.conversation_memory USING btree (expires_at);


--
-- Name: idx_conversation_memory_session_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_memory_session_id ON public.conversation_memory USING btree (session_id);


--
-- Name: idx_conversation_memory_tenant; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_conversation_memory_tenant ON public.conversation_memory USING btree (tenant_code);


--
-- Name: idx_data_sync_logs_completed_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_data_sync_logs_completed_at ON public.data_sync_logs USING btree (completed_at DESC);


--
-- Name: idx_data_sync_logs_entity_type; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_data_sync_logs_entity_type ON public.data_sync_logs USING btree (entity_type);


--
-- Name: idx_data_sync_logs_failures; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_data_sync_logs_failures ON public.data_sync_logs USING btree (status, completed_at DESC) WHERE ((status)::text = ANY ((ARRAY['failed'::character varying, 'partial_success'::character varying])::text[]));


--
-- Name: idx_data_sync_logs_idempotency; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE UNIQUE INDEX idx_data_sync_logs_idempotency ON public.data_sync_logs USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: idx_data_sync_logs_started_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_data_sync_logs_started_at ON public.data_sync_logs USING btree (started_at DESC);


--
-- Name: idx_data_sync_logs_status; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_data_sync_logs_status ON public.data_sync_logs USING btree (status);


--
-- Name: idx_data_sync_logs_sync_type; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_data_sync_logs_sync_type ON public.data_sync_logs USING btree (sync_type);


--
-- Name: idx_data_sync_logs_sync_version; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_data_sync_logs_sync_version ON public.data_sync_logs USING btree (sync_version);


--
-- Name: idx_data_sync_logs_tenant; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_data_sync_logs_tenant ON public.data_sync_logs USING btree (tenant_code);


--
-- Name: idx_saved_reports_created_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_saved_reports_created_at ON public.saved_reports USING btree (created_at);


--
-- Name: idx_saved_reports_pinned; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_saved_reports_pinned ON public.saved_reports USING btree (is_pinned);


--
-- Name: idx_saved_reports_tenant_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_saved_reports_tenant_id ON public.saved_reports USING btree (tenant_id);


--
-- Name: idx_saved_reports_user_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_saved_reports_user_id ON public.saved_reports USING btree (user_id);


--
-- Name: idx_site_visits_created_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_site_visits_created_at ON public.site_visits USING btree (created_at);


--
-- Name: idx_site_visits_idempotency; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE UNIQUE INDEX idx_site_visits_idempotency ON public.site_visits USING btree (tenant_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: idx_site_visits_leadrat_lead_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_site_visits_leadrat_lead_id ON public.site_visits USING btree (leadrat_lead_id);


--
-- Name: idx_site_visits_leadrat_project_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_site_visits_leadrat_project_id ON public.site_visits USING btree (leadrat_project_id);


--
-- Name: idx_site_visits_scheduled_at; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_site_visits_scheduled_at ON public.site_visits USING btree (scheduled_at);


--
-- Name: idx_site_visits_source_updated; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_site_visits_source_updated ON public.site_visits USING btree (source_updated_at DESC);


--
-- Name: idx_site_visits_status; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_site_visits_status ON public.site_visits USING btree (status);


--
-- Name: idx_site_visits_sync_status; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_site_visits_sync_status ON public.site_visits USING btree (sync_status, last_synced_at DESC);


--
-- Name: idx_site_visits_tenant_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_site_visits_tenant_id ON public.site_visits USING btree (tenant_id);


--
-- Name: idx_sitevisit_leadrat_lead; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_sitevisit_leadrat_lead ON public.site_visits USING btree (leadrat_lead_id);


--
-- Name: idx_sitevisit_scheduled; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_sitevisit_scheduled ON public.site_visits USING btree (scheduled_at);


--
-- Name: idx_sitevisit_status; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_sitevisit_status ON public.site_visits USING btree (status);


--
-- Name: idx_sitevisit_tenant; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_sitevisit_tenant ON public.site_visits USING btree (tenant_id);


--
-- Name: idx_tenant_configs_leadrat_code; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_tenant_configs_leadrat_code ON public.tenant_configs USING btree (leadrat_code);


--
-- Name: idx_tenant_configs_tenant_code; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_tenant_configs_tenant_code ON public.tenant_configs USING btree (tenant_code);


--
-- Name: idx_tenants_slug; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_tenants_slug ON public.tenants USING btree (slug);


--
-- Name: idx_users_assigned_leads; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_users_assigned_leads ON public.users USING btree (tenant_id, assigned_leads_count DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_tenant_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_users_tenant_id ON public.users USING btree (tenant_id);


--
-- Name: idx_whatsapp_sessions_idempotency; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE UNIQUE INDEX idx_whatsapp_sessions_idempotency ON public.whatsapp_sessions USING btree (tenant_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: idx_whatsapp_sessions_last_active; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_whatsapp_sessions_last_active ON public.whatsapp_sessions USING btree (last_active);


--
-- Name: idx_whatsapp_sessions_leadrat_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_whatsapp_sessions_leadrat_id ON public.whatsapp_sessions USING btree (leadrat_lead_id);


--
-- Name: idx_whatsapp_sessions_number; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_whatsapp_sessions_number ON public.whatsapp_sessions USING btree (whatsapp_number);


--
-- Name: idx_whatsapp_sessions_source_updated; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_whatsapp_sessions_source_updated ON public.whatsapp_sessions USING btree (source_updated_at DESC);


--
-- Name: idx_whatsapp_sessions_sync_status; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_whatsapp_sessions_sync_status ON public.whatsapp_sessions USING btree (sync_status, last_synced_at DESC);


--
-- Name: idx_whatsapp_sessions_tenant_id; Type: INDEX; Schema: public; Owner: rootuser
--

CREATE INDEX idx_whatsapp_sessions_tenant_id ON public.whatsapp_sessions USING btree (tenant_id);


--
-- Name: ai_query_logs ai_query_logs_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER ai_query_logs_update_trigger BEFORE UPDATE ON public.ai_query_logs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: analytics_summary analytics_summary_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER analytics_summary_update_trigger BEFORE UPDATE ON public.analytics_summary FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: bot_configs bot_configs_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER bot_configs_update_trigger BEFORE UPDATE ON public.bot_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: conversation_logs conversation_logs_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER conversation_logs_update_trigger BEFORE UPDATE ON public.conversation_logs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: conversation_memory conversation_memory_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER conversation_memory_update_trigger BEFORE UPDATE ON public.conversation_memory FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: data_sync_logs data_sync_logs_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER data_sync_logs_update_trigger BEFORE UPDATE ON public.data_sync_logs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: saved_reports saved_reports_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER saved_reports_update_trigger BEFORE UPDATE ON public.saved_reports FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: site_visits site_visits_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER site_visits_update_trigger BEFORE UPDATE ON public.site_visits FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tenant_configs tenant_configs_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER tenant_configs_update_trigger BEFORE UPDATE ON public.tenant_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tenants tenants_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER tenants_update_trigger BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users users_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER users_update_trigger BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: whatsapp_sessions whatsapp_sessions_update_trigger; Type: TRIGGER; Schema: public; Owner: rootuser
--

CREATE TRIGGER whatsapp_sessions_update_trigger BEFORE UPDATE ON public.whatsapp_sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ai_query_logs ai_query_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: ai_query_logs ai_query_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.ai_query_logs
    ADD CONSTRAINT ai_query_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: analytics_summary analytics_summary_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.analytics_summary
    ADD CONSTRAINT analytics_summary_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: bot_configs bot_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.bot_configs
    ADD CONSTRAINT bot_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: conversation_logs conversation_logs_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.conversation_logs
    ADD CONSTRAINT conversation_logs_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.whatsapp_sessions(id) ON DELETE CASCADE;


--
-- Name: conversation_logs conversation_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.conversation_logs
    ADD CONSTRAINT conversation_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: conversation_memory conversation_memory_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.conversation_memory
    ADD CONSTRAINT conversation_memory_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.whatsapp_sessions(id) ON DELETE CASCADE;


--
-- Name: data_sync_logs data_sync_logs_initiated_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.data_sync_logs
    ADD CONSTRAINT data_sync_logs_initiated_by_user_id_fkey FOREIGN KEY (initiated_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: saved_reports saved_reports_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.saved_reports
    ADD CONSTRAINT saved_reports_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: saved_reports saved_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.saved_reports
    ADD CONSTRAINT saved_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: site_visits site_visits_rm_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.site_visits
    ADD CONSTRAINT site_visits_rm_id_fkey FOREIGN KEY (rm_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: site_visits site_visits_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.site_visits
    ADD CONSTRAINT site_visits_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: whatsapp_sessions whatsapp_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rootuser
--

ALTER TABLE ONLY public.whatsapp_sessions
    ADD CONSTRAINT whatsapp_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict bgWFrpL2nYrZ5t63tOHb3NNmJVceluAEZeoKILhmAXEIVSTARg80sztKgrU1YH2

